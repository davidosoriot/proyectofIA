from django.contrib import admin
from .models import Events

admin.site.register(Events)
